#include "pch.h"
#include "Sableye.h"

#include "Image.h"

void Sableye::Init()
{
	mImage = IMAGEMANAGER->FindImage(L"Sableye");
}

void Sableye::Release()
{
}

void Sableye::Update()
{
}

void Sableye::Render(HDC hdc)
{
}
