#include "pch.h"
#include "Unit.h"

void Unit::Init()
{
}

void Unit::Release()
{
}

void Unit::Update()
{
}

void Unit::Render(HDC hdc)
{
}
