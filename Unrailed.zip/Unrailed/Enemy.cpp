#include "pch.h"
#include "Enemy.h"

void Enemy::Init()
{
}

void Enemy::Release()
{
}

void Enemy::Update()
{
}

void Enemy::Render(HDC hdc)
{
}
