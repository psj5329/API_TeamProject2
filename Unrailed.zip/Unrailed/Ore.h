#pragma once
#include "GameObject.h"

enum class OreType
{
	None,
	Green,
	Blue,
	Red
};
class Image;

class Ore :
	public GameObject
{
	OreType mType;
	Image* mImage;
	int mCount;
	int mFrameX;

public:
	void Init()override;
	void Release()override;
	void Update()override;
	void Render(HDC hdc)override;

	int GetOreTypeInt() { return (int)mType; }
	OreType GetOreType() { return mType; }
	int GetCount() { return mCount; }

	void SetOreType(int type) { mType = (OreType)type; }
	void Drop(int x, int y, int type);
	int PickUp();
	void Place(int x, int y);
};

