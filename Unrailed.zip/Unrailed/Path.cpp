#include "pch.h"
#include "Path.h"

#include "StringHelper.h"


const WCHAR* Path::ImageFilter = L"Image\0*.png;*.bmp;*.jpg";
const WCHAR* Path::BinModelFilter = L"Binary Model\0*.model";
const WCHAR* Path::FbxModelFilter = L"Fbx Model\0*.fbx;*.obj\0";
const WCHAR* Path::ShaderFilter = L"HLSL file\0*.hlsl";
const WCHAR* Path::MaterialFilter = L"Material file\0*.material";
const WCHAR* Path::MeshFilter = L"Mesh file\0*.mesh";
const WCHAR* Path::AnimationFilter = L"Animation file\0*.anim";
const WCHAR* Path::ColliderFilter = L"Collider file\0*.collider";

//bool Path::ExistFile(string path)
//{
//	return ExistFile(StringHelper::StringToWString(path));
//}
//
//bool Path::ExistFile(wstring path)
//{
//	DWORD fileValue = GetFileAttributes(path.c_str());
//
//	return fileValue < 0xFFFFFFFF;
//}
//
//string Path::Combine(string path1, string path2)
//{
//	return path1 + path2;
//}
//
//wstring Path::Combine(wstring path1, wstring path2)
//{
//	return path1 + path2;
//}
//
//bool Path::ExistDirectory(wstring path)
//{
//	DWORD attribute = GetFileAttributes(path.c_str());
//
//	BOOL temp = (attribute != INVALID_FILE_ATTRIBUTES &&
//		(attribute & FILE_ATTRIBUTE_DIRECTORY));
//
//	return temp == TRUE;
//}
//
//string Path::Combine(vector<string> paths)
//{
//	string temp = "";
//	for (string path : paths)
//		temp += path;
//
//	return temp;
//}
//
//wstring Path::Combine(vector<wstring> paths)
//{
//	wstring temp = L"";
//	for (wstring path : paths)
//		temp += path;
//
//	return temp;
//}
//
//string Path::GetDirectoryName(string path)
//{
//	size_t index = path.find_last_of('/');
//
//	return path.substr(0, index + 1);
//}
//
//wstring Path::GetDirectoryName(wstring path)
//{
//	size_t index = path.find_last_of('/');
//
//	return path.substr(0, index + 1);
//}
//
//string Path::GetExtension(string path)
//{
//	size_t index = path.find_last_of('.');
//
//	return path.substr(index + 1, path.length());;
//}
//
//wstring Path::GetExtension(wstring path)
//{
//	size_t index = path.find_last_of('.');
//
//	return path.substr(index + 1, path.length());;
//}
//
//string Path::GetFileName(string path)
//{
//	size_t index = path.find_last_of('/');
//
//	return path.substr(index + 1, path.length());
//}
//
//wstring Path::GetFileName(wstring path)
//{
//	size_t index = path.find_last_of('/');
//
//	return path.substr(index + 1, path.length());
//}
//
//string Path::GetFileNameWithoutExtension(string path)
//{
//	string fileName = GetFileName(path);
//
//	size_t index = fileName.find_last_of('.');
//	return fileName.substr(0, index);
//}
//
//wstring Path::GetFileNameWithoutExtension(wstring path)
//{
//	wstring fileName = GetFileName(path);
//
//	size_t index = fileName.find_last_of('.');
//	return fileName.substr(0, index);
//}
//
//string Path::GetFilePathWithoutExtension(string path)
//{
//	size_t index = path.find_last_of('.');
//	return path.substr(0, index);
//}
//
//wstring Path::GetFilePathWithoutExtension(wstring path)
//{
//	size_t index = path.find_last_of('.');
//	return path.substr(0, index);
//}


void Path::OpenFileDialog(wstring file, const WCHAR* filter, wstring folder, function<void(wstring)> func, HWND hwnd)
{
	WCHAR name[255];
	wcscpy_s(name, file.c_str());

	wstring tempFolder = folder;
	StringHelper::Replace(&tempFolder, L"/", L"\\");

	OPENFILENAME ofn;
	ZeroMemory(&ofn, sizeof(OPENFILENAME));
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.hwndOwner = hwnd;
	ofn.lpstrFilter = filter;
	ofn.lpstrFile = name;
	//ofn.lpstrFileTitle = L"�ҷ�����";
	ofn.nMaxFile = 255;
	ofn.lpstrInitialDir = tempFolder.c_str();
	ofn.Flags = OFN_NOCHANGEDIR;

	if (GetOpenFileName(&ofn) == TRUE)
	{
		wstring loadName = name;
		
		StringHelper::Replace(&loadName, L"\\", L"/");
		string str = StringHelper::WStringToString(loadName);
		cout << str << endl;
		if (func != NULL)
		{

			func(loadName);
		
		}
	}
}

void Path::SaveFileDialog(wstring file, const WCHAR* filter, wstring folder, function<void(wstring)> func, HWND hwnd)
{
	WCHAR name[255];
	wcscpy_s(name, file.c_str());

	wstring tempFolder = folder;
	StringHelper::Replace(&tempFolder, L"/", L"\\");

	OPENFILENAME ofn;
	ZeroMemory(&ofn, sizeof(OPENFILENAME));
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.hwndOwner = hwnd;
	ofn.lpstrFilter = filter;
	ofn.lpstrFile = name;
	//ofn.lpstrFileTitle = L"";
	ofn.nMaxFile = 255;
	ofn.lpstrInitialDir = tempFolder.c_str();
	ofn.Flags = OFN_NOCHANGEDIR;

	if (GetSaveFileName(&ofn) == TRUE)
	{
		if (func != NULL)
		{
			wstring loadName = name;
			StringHelper::Replace(&loadName, L"\\", L"/");

			func(loadName);
		}
	}
}